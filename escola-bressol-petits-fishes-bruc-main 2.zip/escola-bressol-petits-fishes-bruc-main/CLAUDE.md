# CLAUDE.md

## Project

Daily diary SPA for **Escola Bressol Petits Fishes (Bruc)**, a Catalan nursery school. Mobile-first single page that shows each day's activities and menu, with swipe left/right to change day and a calendar drawer for jumping to any date. All UI copy is in Catalan. Footer disclaims: *"🥸 no oficial - pot contenir errors"*.

## Run locally

```
npm install
npm start
```

`npm start` runs [`servor`](package.json) — a zero-config static dev server with live reload. No build step, no tests, no lint.

## Layout

- [index.html](index.html) — **the entire app** (HTML + inline `<style>` + inline `<script>`).
- [calendar.csv](calendar.csv) — content source. Columns: `Date,Type,Label,Activities,Menu`. Pipe (`|`) separates list items inside `Activities` and `Menu`.
- [manifest.json](manifest.json), [sw.js](sw.js) — PWA: installable + offline. SW uses stale-while-revalidate; cache is `fishes-v1`. Bump the cache name in `sw.js` to force a refresh.
- [favicon.png](favicon.png) — icon (used as PWA icon too).
- [script.js](script.js), [styles.css](styles.css) — **leftover scaffold, not referenced by `index.html`.** Don't edit these unless you also wire them in.
- [package.json](package.json), [package-lock.json](package-lock.json) — dev server dependency only.

## Tech stack

- Tailwind via CDN (`cdn.tailwindcss.com`), config inline in `index.html`.
- Lucide icons via CDN.
- Google Fonts: Nunito.
- Vercel Web Analytics — deployment target is Vercel (`/_vercel/insights/script.js`).
- No bundler, no transpiler, no framework.

## Editing content (most common change)

Edit [calendar.csv](calendar.csv).

- `Date`: `YYYY-MM-DD`.
- `Type`: `school` or `holiday`.
- `holiday` rows use only `Label` (e.g. *"Any Nou 🎉"*).
- `school` rows: `Label` is an optional banner (e.g. *"Aniversari Bruno 🎂"*); `Activities` and `Menu` are `|`-separated lists.
- Parser: `parseCSVtoCalendarDB` in [index.html:157](index.html).

## Editing app code

All JS lives in the trailing `<script>` block of [index.html](index.html).

- Single global `state` object: `selectedDate`, `month`, `year`, `isCalendarOpen`.
- Renderers: `renderHeader`, `renderMainContent`, plus a calendar grid renderer.
- `initializeApp` ([index.html:643](index.html)) defaults to today's date if its month exists in the CSV; otherwise the first month present.
- Catalan day names (`DILLUNS`–`DIUMENGE`) and month names (`GENER`–`DESEMBRE`) are hardcoded — keep all UI copy in Catalan.
- Touch handlers at the bottom of `<script>` implement left/right swipe to change day.
- **Project song per month**: `SONGS_BY_MONTH` (keyed by `YYYY-MM`) at the top of `<script>`. When a month has a URL, activities containing "cançó" show a ▶ button via `formatActivityText` / `getCurrentSongUrl`.

## Repo state

Not a git repo — `.gitignore` exists but there's no `.git/`. Don't run `git` commands assuming history.
